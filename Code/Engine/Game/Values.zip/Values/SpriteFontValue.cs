﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExplorationGame.ValueForms;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ExplorationGame
{
    public class SpriteFontValue : Value
    {
        private SpriteFont Value;
        private string Path;

        public SpriteFontValue(string Name)
            : base(Name)
        {
            this.Value = null;
            this.Path = "";
        }

        public SpriteFontValue(string Name, string Path)
            : base(Name)
        {
            this.Value = LoadSpriteFont(Path);
        }

        public SpriteFontValue(string Name, SpriteFont Value)
            : base(Name)
        {
            this.Value = Value;
            this.Path = "";
        }

        public SpriteFontValue(string Name, SpriteFont Value, string Path)
            : base(Name)
        {
            this.Value = Value;
            this.Path = Path;
        }

        public SpriteFont LoadSpriteFont(string Path)
        {
            this.Path = Path;
            return AssetManager.Load<SpriteFont>(Path);
        }

        public SpriteFont get()
        {
            return Value;
        }

        public string getPath()
        {
            return Path;
        }

        public void set(string Path)
        {
            this.Value = LoadSpriteFont(Path);
        }

        public void set(SpriteFont Value)
        {
            this.Value = Value;
        }

        public void set(SpriteFont Value, string Path)
        {
            this.Value = Value;
            this.Path = Path;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new SpriteFontForm(Values);
        }
    }
}
