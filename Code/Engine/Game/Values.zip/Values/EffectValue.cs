﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExplorationGame.ValueForms;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ExplorationGame
{
    public class EffectValue : Value
    {
        private Effect Value;
        private string Path;

        public EffectValue(string Name)
            : base(Name)
        {
            this.Value = null;
            this.Path = "";
        }

        public EffectValue(string Name, string Path)
            : base(Name)
        {
            this.Value = LoadEffect(Path);
        }

        public EffectValue(string Name, Effect Value)
            : base(Name)
        {
            this.Value = Value;
            this.Path = "";
        }

        public EffectValue(string Name, Effect Value, string Path)
            : base(Name)
        {
            this.Value = Value;
            this.Path = Path;
        }

        public Effect LoadEffect(string Path)
        {
            this.Path = Path;
            return AssetManager.Load<Effect>(Path);
        }

        public Effect get()
        {
            return Value;
        }

        public string getPath()
        {
            return Path;
        }

        public void set(string Path)
        {
            this.Value = LoadEffect(Path);
        }

        public void set(Effect Value)
        {
            this.Value = Value;
        }

        public void set(Effect Value, string Path)
        {
            this.Value = Value;
            this.Path = Path;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new EffectForm(Values);
        }
    }
}
