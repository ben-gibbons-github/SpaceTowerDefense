﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using ExplorationGame.ValueForms;

namespace ExplorationGame
{
    public class Vector4Value : Value
    {
        private Vector4 Value;

        public Vector4Value(string Name)
            : base(Name)
        {
            this.Value = Vector4.Zero;
        }

        public Vector4Value(string Name, Vector4 Value)
            : base(Name)
        {
            this.Value = Value;
        }

        public Vector4 get()
        {
            return Value;
        }

        public void set(Vector4 Value)
        {
            this.Value = Value;
        }

        public void setX(float X)
        {
            Value.X = X;
        }

        public void setY(float Y)
        {
            Value.Y = Y;
        }

        public void setZ(float Z)
        {
            Value.Z = Z;
        }

        public void setW(float W)
        {
            Value.W = W;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new Vector4Form(Values);
        }
    }
}
