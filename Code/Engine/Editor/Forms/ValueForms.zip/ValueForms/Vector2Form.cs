﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ExplorationGame.ValueForms
{
    public class Vector2Form : ValueForm
    {
        public ValueHolder XHolder;
        public ValueHolder YHolder;

        public Vector2Form(LinkedList<Value> ReferenceValues)
            : base(ReferenceValues)
        {
            AddForm(XHolder = new ValueHolder(this, "- X: ", GetValueFromField));
            AddForm(YHolder = new ValueHolder(this, "- Y: ", GetValueFromField));

            GetValueFromReferences();
        }

        public override void Create(FormHolder Parent)
        {
            Vector2 Size = Font.MeasureString(Name) + new Vector2(0, ValueForm.Buffer * 3 + YHolder.ValueField.Size.Y);

            foreach (Form f in FormChildren)
                Size.X = Math.Max(f.Size.X, Size.X);

            SetSize(Size);

            base.Create(Parent);
        }

        public override void SetPosition(Vector2 Position)
        {
            YHolder.SetPosition(Position + 
               Font.MeasureString(Name) + new Vector2(ValueForm.Buffer)
                );
            XHolder.SetPosition(Position + new Vector2(Font.MeasureString(Name).X + ValueForm.Buffer, 0));

            base.SetPosition(Position);
        }

        public override void GetValueFromReferences()
        {
            foreach (Vector2Value val in ReferenceValues)
            {
                if (val == ReferenceValues.First.Value)
                {
                    Name = val.Name;
                    XHolder.set(val.get().X, false);
                    YHolder.set(val.get().Y, false);
                }
                else
                {
                    if (XHolder.Value != val.get().X)
                        XHolder.set(true);
                    if (YHolder.Value != val.get().Y)
                        YHolder.set(true);
                }
            }
        }

        public override void GetValueFromField()
        {
            XHolder.get();
            YHolder.get();

            foreach (Vector2Value val in ReferenceValues)
            {
                if (!XHolder.NoValue)
                    val.setX(XHolder.Value);
                if (!YHolder.NoValue)
                    val.setY(YHolder.Value);
            }

            base.GetValueFromField();
        }


        public override void Draw()
        {
            //XHolder.Draw();
            //YHolder.Draw();

            Game1.spriteBatch.DrawString(Font, Name, Position, TextColor);
            base.Draw();
        }

    }
}
