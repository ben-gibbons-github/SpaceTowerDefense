﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExplorationGame
{
    public class Value
    {
        public GameObject Parent;
        public string Name;

        public Value(string Name)
        {
            this.Parent = Level.ReferenceObject;
            this.Name = Name;

            Parent.AddValue(this);
        }

        public virtual Form GetForm(LinkedList<Value> Values)
        {
            return null;
        }

    }
}
