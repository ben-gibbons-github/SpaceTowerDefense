﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExplorationGame.ValueForms;

namespace ExplorationGame
{
    public class FloatValue : Value
    {
        private float Value;

        public FloatValue(string Name):base(Name)
        {
            this.Value = 0;
        }

        public FloatValue(string Name, float Value)
            : base(Name)
        {
            this.Value = Value;
        }

        public float get()
        {
            return Value;
        }

        public void set(float Value)
        {
            this.Value = Value;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new FloatForm(Values);
        }
    }
}
