﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExplorationGame.ValueForms;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ExplorationGame
{
    public class ModelValue : Value
    {
        private Model Value;
        private string Path;

        public ModelValue(string Name)
            : base(Name)
        {
            this.Value = null;
            this.Path = "";
        }

        public ModelValue(string Name, string Path)
            : base(Name)
        {
            this.Value = LoadModel(Path);
        }

        public ModelValue(string Name, Model Value)
            : base(Name)
        {
            this.Value = Value;
            this.Path = "";
        }

        public ModelValue(string Name, Model Value, string Path)
            : base(Name)
        {
            this.Value = Value;
            this.Path = Path;
        }

        public Model LoadModel(string Path)
        {
            this.Path = Path;
            return AssetManager.Load<Model>(Path);
        }

        public Model get()
        {
            return Value;
        }

        public string getPath()
        {
            return Path;
        }

        public void set(string Path)
        {
            this.Value = LoadModel(Path);
        }

        public void set(Model Value)
        {
            this.Value = Value;
        }

        public void set(Model Value, string Path)
        {
            this.Value = Value;
            this.Path = Path;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new ModelForm(Values);
        }
    }
}
