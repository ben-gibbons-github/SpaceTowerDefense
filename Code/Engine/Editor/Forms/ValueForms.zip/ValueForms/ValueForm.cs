﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ExplorationGame.ValueForms
{
    public class ValueForm : Form
    {
        public LinkedList<Value> ReferenceValues = new LinkedList<Value>();
        public string Name;
        public Color TextColor = FormFormat.TextColor;
        public SpriteFont Font = FormFormat.NormalFont;

        public static int Buffer = 10;

        public ValueForm(LinkedList<Value> ReferenceValues)
        {
            this.ReferenceValues = ReferenceValues;
        }

        public virtual void GetValueFromReferences()
        {

        }

        public virtual void GetValueFromField()
        {

        }
    }
}
