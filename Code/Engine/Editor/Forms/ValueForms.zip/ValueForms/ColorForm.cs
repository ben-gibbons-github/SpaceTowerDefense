﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ExplorationGame.ValueForms
{
    public class ColorForm : ValueForm
    {
        public SliderHolder RHolder;
        public SliderHolder GHolder;
        public SliderHolder BHolder;
        public SliderHolder AHolder;
        public SliderHolder IHolder;

        public Texture2D RectTexture = Render.BlankTexture;


        public ColorForm(LinkedList<Value> ReferenceValues)
            : base(ReferenceValues)
        {
            AddForm(RHolder = new SliderHolder(this, "R", GetValueFromField, 0, 1));
            AddForm(GHolder = new SliderHolder(this, "G", GetValueFromField, 0, 1));
            AddForm(BHolder = new SliderHolder(this, "B", GetValueFromField, 0, 1));
            AddForm(AHolder = new SliderHolder(this, "A", GetValueFromField, 0, 1));
            AddForm(IHolder = new SliderHolder(this, "I", GetValueFromField, 0, 10));

            GetValueFromReferences();
        }

        public override void Create(FormHolder Parent)
        {
            Vector2 Size = Font.MeasureString(Name) + new Vector2(0, ValueForm.Buffer * 6 + RHolder.ValueField.Size.Y * 5);

            foreach (Form f in FormChildren)
                Size.X = Math.Max(f.Size.X, Size.X);

            SetSize(Size);

            base.Create(Parent);
        }

        public override void SetPosition(Vector2 Position)
        {
            Vector2 FormPosition = Position;
            FormPosition.Y += Font.MeasureString(Name).Y;
            FormPosition += new Vector2( ValueForm.Buffer);

            foreach (Form f in Children)
            {
                f.SetPosition(FormPosition);
                FormPosition.Y += ValueForm.Buffer + f.Size.Y;
            }

            base.SetPosition(Position);
        }

        public override void GetValueFromReferences()
        {
            foreach (ColorValue val in ReferenceValues)
            {
                if (val == ReferenceValues.First.Value)
                {
                    Name = val.Name;
                    RHolder.set(val.getBase().X, false);
                    GHolder.set(val.getBase().Y, false);
                    BHolder.set(val.getBase().Z, false);
                    AHolder.set(val.getBase().W, false);
                    IHolder.set(val.getMult(), false);
                }
                else
                {
                    if (RHolder.Value != val.getBase().X)
                        RHolder.set(true);
                    if (GHolder.Value != val.getBase().Y)
                        GHolder.set(true);
                    if (BHolder.Value != val.getBase().Z)
                        BHolder.set(true);
                    if (AHolder.Value != val.getBase().W)
                        AHolder.set(true);
                    if (IHolder.Value != val.getMult())
                        IHolder.set(true);
                }
            }
        }

        public override void GetValueFromField()
        {
            RHolder.get();
            GHolder.get();
            BHolder.get();
            AHolder.get();
            IHolder.get();

            foreach (ColorValue val in ReferenceValues)
            {
                if (!RHolder.NoValue)
                    val.setR(RHolder.Value);
                if (!GHolder.NoValue)
                    val.setG(GHolder.Value);
                if (!BHolder.NoValue)
                    val.setB(BHolder.Value);
                if (!AHolder.NoValue)
                    val.setA(AHolder.Value);
                if (!IHolder.NoValue)
                    val.setIntensity(IHolder.Value);
            }

            base.GetValueFromField();
        }


        public override void Draw()
        {

            Game1.spriteBatch.DrawString(Font, Name, Position, TextColor);
            base.Draw();
        }

    }
}
