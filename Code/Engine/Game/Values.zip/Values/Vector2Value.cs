﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using ExplorationGame.ValueForms;

namespace ExplorationGame
{
    public class Vector2Value : Value
    {
        private Vector2 Value;

        public Vector2Value(string Name)
            : base(Name)
        {
            this.Value = Vector2.Zero;
        }

        public Vector2Value(string Name, Vector2 Value)
            : base(Name)
        {
            this.Value = Value;
        }

        public Vector2 get()
        {
            return Value;
        }

        public void set(Vector2 Value)
        {
            this.Value = Value;
        }

        public void setX(float X)
        {
            Value.X = X;
        }

        public void setY(float Y)
        {
            Value.Y = Y;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new Vector2Form(Values);
        }
    }
}
