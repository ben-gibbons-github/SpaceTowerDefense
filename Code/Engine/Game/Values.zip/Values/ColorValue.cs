﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using ExplorationGame.ValueForms;

namespace ExplorationGame
{
    public class ColorValue : Value
    {
        private Vector4 Value;
        private float Mult = 1;

        public ColorValue(string Name)
            : base(Name)
        {
            this.Value = Vector4.One;
        }

        public ColorValue(string Name, Vector4 Value)
            : base(Name)
        {
            this.Value = Value;
        }

        public ColorValue(string Name, Vector4 Value, float Mult)
            : base(Name)
        {
            this.Value = Value;
            this.Mult = Mult;
        }

        public Vector4 get()
        {
            return Value * Mult;
        }

        public Vector4 getBase()
        {
            return Value;
        }

        public float getMult()
        {
            return Mult;
        }

        public void set(Vector4 Value)
        {
            this.Value = Value;
        }

        public void set(Vector4 Value, float Mult)
        {
            this.Value = Value;
            this.Mult = Mult;
        }

        public void setR(float Value)
        {
            this.Value.X = Value;
        }

        public void setG(float Value)
        {
            this.Value.Y = Value;
        }

        public void setB(float Value)
        {
            this.Value.Z = Value;
        }

        public void setA(float Value)
        {
            this.Value.W = Value;
        }

        public void setIntensity(float Value)
        {
            this.Mult = Value;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new ColorForm(Values);
        }
    }
}
