﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using ExplorationGame.ValueForms;

namespace ExplorationGame
{
    public class Vector3Value : Value
    {
        private Vector3 Value;

        public Vector3Value(string Name)
            : base(Name)
        {
            this.Value = Vector3.Zero;
        }

        public Vector3Value(string Name, Vector3 Value)
            : base(Name)
        {
            this.Value = Value;
        }

        public Vector3 get()
        {
            return Value;
        }

        public void set(Vector3 Value)
        {
            this.Value = Value;
        }

        public void setX(float X)
        {
            Value.X = X;
        }

        public void setY(float Y)
        {
            Value.Y = Y;
        }

        public void setZ(float Z)
        {
            Value.Z = Z;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new Vector3Form(Values);
        }
    }
}
