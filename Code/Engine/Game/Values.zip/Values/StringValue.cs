﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExplorationGame.ValueForms;

namespace ExplorationGame
{
    public class StringValue : Value
    {
        private string Value;

        public StringValue(string Name)
            : base(Name)
        {
            this.Value = "";
        }

        public StringValue(string Name, string Value)
            : base(Name)
        {
            this.Value = Value;
        }

        public string get()
        {
            return Value;
        }

        public void set(string Value)
        {
            this.Value = Value;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new StringForm(Values);
        }
    }
}
