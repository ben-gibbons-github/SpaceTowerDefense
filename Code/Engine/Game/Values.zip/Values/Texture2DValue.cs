﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExplorationGame.ValueForms;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ExplorationGame
{
    public class Texture2DValue : Value
    {
        private Texture2D Value;
        private string Path;

        public Texture2DValue(string Name)
            : base(Name)
        {
            this.Value = null;
            this.Path = "";
        }

        public Texture2DValue(string Name, string Path)
            : base(Name)
        {
            this.Value = LoadTexture(Path);
        }

        public Texture2DValue(string Name, Texture2D Value)
            : base(Name)
        {
            this.Value = Value;
            this.Path = "";
        }

        public Texture2DValue(string Name, Texture2D Value, string Path)
            : base(Name)
        {
            this.Value = Value;
            this.Path = Path;
        }

        public Texture2D LoadTexture(string Path)
        {
            this.Path = Path;
            return AssetManager.Load<Texture2D>(Path);
        }

        public Texture2D get()
        {
            return Value;
        }

        public string getPath()
        {
            return Path;
        }

        public void set(string Path)
        {
            this.Value = LoadTexture(Path);
        }

        public void set(Texture2D Value)
        {
            this.Value = Value;
        }

        public void set(Texture2D Value, string Path)
        {
            this.Value = Value;
            this.Path = Path;
        }

        public override Form GetForm(LinkedList<Value> Values)
        {
            return new Texture2DForm(Values);
        }
    }
}
